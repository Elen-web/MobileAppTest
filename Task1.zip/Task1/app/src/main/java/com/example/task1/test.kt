import java.util.Scanner

fun main() {
    val scanner = Scanner(System.`in`)

    print("Enter your name: ")
    val name = scanner.nextLine()

    println("Hello, $name!")

    scanner.close()
}
